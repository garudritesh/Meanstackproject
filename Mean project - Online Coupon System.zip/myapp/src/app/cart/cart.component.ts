import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  public sessionid = sessionStorage.getItem("sessionid");

   public data = {
    id: this.sessionid
  } 
  public list:any =[];


  constructor(private router:Router,private http: HttpClient ) { }

  ngOnInit(): void {
    if(!sessionStorage.getItem("sid")){
      this.router.navigate(["login"])
    }

    this.getproduct()
   
  }
 
   async getproduct(){
    
    const url = 'http://localhost:3000/getproduct';
    const result: any = await this.http.post(url, this.data).toPromise();
   
    this.list =result;
    console.log(this.list)
   }

   async delete(input,id){
    let obj ={input,id}
    const url = 'http://localhost:3000/delete';
    await this.http.post(url,obj).toPromise();
    this.getproduct()
   }

}
