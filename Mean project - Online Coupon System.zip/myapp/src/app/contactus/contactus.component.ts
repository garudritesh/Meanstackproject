import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators,FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {

 
  
  public fbFormGroup = this.fb.group({
    firstname: ['', Validators.required],
    lastname: ['', Validators.required],
    email: ['', Validators.required],
    comments: ['', Validators.required],
   
  });
 

  constructor(private router:Router,private fb: FormBuilder,   private http: HttpClient) { }

  ngOnInit(): void {
  }

  async commenthere() {
   
    const data = this.fbFormGroup.value;
      const url = 'http://localhost:3000/addcomment';
  
      await this.http.post(url, data).toPromise();
    
  }

}
