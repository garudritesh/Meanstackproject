import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-forgetpassword',
  templateUrl: './forgetpassword.component.html',
  styleUrls: ['./forgetpassword.component.css']
})
export class ForgetpasswordComponent implements OnInit {

  
  public id = sessionStorage.getItem("rig");
  constructor(private router:Router,private fb: FormBuilder,private http: HttpClient) { }

  ngOnInit(): void {
  }

  
  public fbFormGroup = this.fb.group({
    
    email: ['', [Validators.required]]
   
  });


  async forgotProcessHere() {
    
    //const data = {email : "pranays297@gmail.com"}
    const data_1 = this.fbFormGroup.value;
    const url = 'http://localhost:3000/checkForgotuser';
    const result: any = await this.http.post(url, data_1).toPromise();
console.log(result)
    if (result[0].email ) {
      const data = this.fbFormGroup.value;
     //console.log(data.pwd)
      const url = 'http://localhost:3000/sendPass';
       await this.http.post(url, result).toPromise();
      this.router.navigate(['login']);
     
      }
  
  }



  toNavigate(page){
    this.router.navigate([page]);
  }
}
