import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public sessionid = sessionStorage.getItem("sessionid");

   public data = {
    productname:"flipcart",
    couponcode :"GetFlip",
    discount : "30%",
    id: this.sessionid
  } 
  public data1 = {
    productname:"Zomato",
    couponcode :"ZomatoFree",
    discount : "30%",
    id: this.sessionid
  } 
  public data2 = {
    productname:"Myntra",
    couponcode :"MyntraNew",
    discount : "80%",
    id: this.sessionid
  } 

  public data3= {
    productname:"Price Cash",
    couponcode :" New Year Offer",
    discount : "10%",
    id: this.sessionid
  } 
  public data4= {
    productname:"Amazon",
    couponcode :"Get Amazon",
    discount : "60%",
    id: this.sessionid
  } 
  public data5= {
    productname:"RichLook",
    couponcode :"Richlook40",
    discount : "40%",
    id: this.sessionid
  } 
  public data6= {
    productname:"PayTm",
    couponcode :"Trip15",
    discount : "15%",
    id: this.sessionid
  } 
  public data7= {
    productname:"Brand Factory",
    couponcode :"BF500",
    discount : "70% + 500rs",
    id: this.sessionid
  } 
  public data8= {
    productname:"Fashion Trends",
    couponcode :"GetFashion",
    discount : "50%",
    id: this.sessionid
  } 
  public data9= {
    productname:"Any Pizza",
    couponcode :"MJES199",
    discount : "199rs",
    id: this.sessionid
  } 
  public data10= {
    productname:"PizzHut",
    couponcode :"Phut50",
    discount : "50%",
    id: this.sessionid
  } 
  constructor(private router:Router,private http: HttpClient) { }

  ngOnInit(): void {
  }
  async dominos(){
    const url = 'http://localhost:3000/addtocart';
  
      await this.http.post(url, this.data).toPromise();
 
  }
  async zomato(){
    const url = 'http://localhost:3000/addtocart';
  
    await this.http.post(url, this.data1).toPromise();

  }
  async myntra(){
    const url = 'http://localhost:3000/addtocart';
  
    await this.http.post(url, this.data2).toPromise();

  }
  async cash(){
    const url = 'http://localhost:3000/addtocart';
  
    await this.http.post(url, this.data3).toPromise();

  }
  async amazonnew(){
    const url = 'http://localhost:3000/addtocart';
  
    await this.http.post(url, this.data4).toPromise();

  }
  async richlook(){
    const url = 'http://localhost:3000/addtocart';
  
    await this.http.post(url, this.data5).toPromise();

  }
  async paytm(){
    const url = 'http://localhost:3000/addtocart';
  
    await this.http.post(url, this.data6).toPromise();

  }
  async BF(){
    const url = 'http://localhost:3000/addtocart';
  
    await this.http.post(url, this.data7).toPromise();

  }
  async trends(){
    const url = 'http://localhost:3000/addtocart';
  
    await this.http.post(url, this.data8).toPromise();

  }
  async mojo(){
    const url = 'http://localhost:3000/addtocart';
  
    await this.http.post(url, this.data9).toPromise();

  }
  async pizzahut(){
    const url = 'http://localhost:3000/addtocart';
  
    await this.http.post(url, this.data10).toPromise();

  }
}
