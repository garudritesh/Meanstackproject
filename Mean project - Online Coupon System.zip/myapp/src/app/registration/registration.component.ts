import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, Validators,FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  
  public fbFormGroup = this.fb.group({
    username: ['', [Validators.required,Validators.pattern('^[a-zA-Z ]{5,20}$')]],
    email: ['', [Validators.required,Validators.pattern('^[A-Za-z0-9_.]{4,20}@[A-Za-z]{3,8}\.[A-Za-z]{2,10}$'),],],
    pwd: ['', [Validators.required,Validators.pattern('^[a-zA-Z ]{5,20}$')]],
   
  });
 
  public uiInvalidCredential = false;
  
  public uiInvalidCredential2 = false;
  //gmail = new FormControl("");
  constructor(private router:Router,private fb: FormBuilder,   private http: HttpClient) { }

  ngOnInit(): void {
  }

 /*  async chechEmail() {
    const data = {email :"garudritesh@gmail.com"};

    const url = 'http://localhost:3000/checkmail';
    const result: any = await this.http.post(url, data).toPromise();
    if (result.opr) {
      this.router.navigate(['register']);
    } else{  this.flag1=2}

  } */

 
  async loginProcessHere() {
   
    const data1 = this.fbFormGroup.value;

    const url1 = 'http://localhost:3000/checkmail';
    const result: any = await this.http.post(url1, data1).toPromise();
    if (result.opr) {
      const data = this.fbFormGroup.value;
    
      const url = 'http://localhost:3000/add';
  
      await this.http.post(url, data).toPromise();
      this.router.navigate(['login']);
    
    } else {
      this.uiInvalidCredential = true;

    }

  }
}
